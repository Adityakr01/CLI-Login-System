package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"

	"github.com/osto/clilogin/internal/cli"
	"github.com/osto/clilogin/internal/db"
	"github.com/osto/clilogin/internal/repo"
)

func main() {
	dbPath := flag.String("db", envOr("DB_PATH", "/data/clilogin.db"), "path to the SQLite database file")
	historyPath := flag.String("history", envOr("HISTORY_PATH", "/data/.clilogin_history"), "path to the CLI history file")
	flag.Parse()

	if dir := filepath.Dir(*dbPath); dir != "." {
		_ = os.MkdirAll(dir, 0o755)
	}

	conn, err := db.Open(*dbPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, "failed to open database:", err)
		os.Exit(1)
	}
	defer conn.Close()

	users := repo.NewUserRepo(conn)
	sessions := repo.NewSessionRepo(conn)
	_ = sessions.DeleteExpired()

	svc := cli.NewService(users, sessions)
	if err := svc.Run(*historyPath); err != nil {
		fmt.Fprintln(os.Stderr, "fatal error:", err)
		os.Exit(1)
	}
}

func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
