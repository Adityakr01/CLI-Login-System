package repo

import (
	"database/sql"
	"errors"
	"time"

	"github.com/osto/clilogin/internal/models"
)

var ErrNotFound = errors.New("not found")
var ErrDuplicate = errors.New("username already exists")

type UserRepo struct {
	db *sql.DB
}

func NewUserRepo(db *sql.DB) *UserRepo {
	return &UserRepo{db: db}
}

func (r *UserRepo) Create(username, passwordHash string) (*models.User, error) {
	res, err := r.db.Exec(
		`INSERT INTO users (username, password_hash) VALUES (?, ?)`,
		username, passwordHash,
	)
	if err != nil {
		if isUniqueConstraintErr(err) {
			return nil, ErrDuplicate
		}
		return nil, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	return r.GetByID(id)
}

func (r *UserRepo) GetByUsername(username string) (*models.User, error) {
	row := r.db.QueryRow(
		`SELECT id, username, password_hash, totp_secret, mfa_enabled,
		        created_at, last_login_at, failed_attempts, locked_until
		 FROM users WHERE username = ?`, username,
	)
	return scanUser(row)
}

func (r *UserRepo) GetByID(id int64) (*models.User, error) {
	row := r.db.QueryRow(
		`SELECT id, username, password_hash, totp_secret, mfa_enabled,
		        created_at, last_login_at, failed_attempts, locked_until
		 FROM users WHERE id = ?`, id,
	)
	return scanUser(row)
}

func scanUser(row *sql.Row) (*models.User, error) {
	var u models.User
	var totpSecret sql.NullString
	var mfaEnabled int
	var lastLogin sql.NullTime
	var lockedUntil sql.NullTime

	err := row.Scan(&u.ID, &u.Username, &u.PasswordHash, &totpSecret, &mfaEnabled,
		&u.CreatedAt, &lastLogin, &u.FailedAttempts, &lockedUntil)
	if err == sql.ErrNoRows {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	u.TOTPSecret = totpSecret.String
	u.MFAEnabled = mfaEnabled == 1
	if lastLogin.Valid {
		t := lastLogin.Time
		u.LastLoginAt = &t
	}
	if lockedUntil.Valid {
		t := lockedUntil.Time
		u.LockedUntil = &t
	}
	return &u, nil
}

func (r *UserRepo) SetTOTPSecret(userID int64, secret string, enabled bool) error {
	_, err := r.db.Exec(
		`UPDATE users SET totp_secret = ?, mfa_enabled = ? WHERE id = ?`,
		secret, boolToInt(enabled), userID,
	)
	return err
}

func (r *UserRepo) DisableMFA(userID int64) error {
	_, err := r.db.Exec(
		`UPDATE users SET totp_secret = NULL, mfa_enabled = 0 WHERE id = ?`, userID,
	)
	return err
}

func (r *UserRepo) RecordSuccessfulLogin(userID int64) error {
	_, err := r.db.Exec(
		`UPDATE users SET last_login_at = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?`,
		time.Now(), userID,
	)
	return err
}

// RegisterFailedAttempt increments the failure counter and locks the account
// once maxAttempts is reached, for lockDuration.
func (r *UserRepo) RegisterFailedAttempt(userID int64, maxAttempts int, lockDuration time.Duration) error {
	u, err := r.GetByID(userID)
	if err != nil {
		return err
	}
	attempts := u.FailedAttempts + 1
	if attempts >= maxAttempts {
		until := time.Now().Add(lockDuration)
		_, err = r.db.Exec(
			`UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?`,
			attempts, until, userID,
		)
		return err
	}
	_, err = r.db.Exec(`UPDATE users SET failed_attempts = ? WHERE id = ?`, attempts, userID)
	return err
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

func isUniqueConstraintErr(err error) bool {
	return err != nil && (containsAny(err.Error(), []string{"UNIQUE constraint failed", "constraint failed"}))
}

func containsAny(s string, subs []string) bool {
	for _, sub := range subs {
		if len(s) >= len(sub) {
			for i := 0; i+len(sub) <= len(s); i++ {
				if s[i:i+len(sub)] == sub {
					return true
				}
			}
		}
	}
	return false
}

// ---- Sessions ----

type SessionRepo struct {
	db *sql.DB
}

func NewSessionRepo(db *sql.DB) *SessionRepo {
	return &SessionRepo{db: db}
}

func (r *SessionRepo) Create(id string, userID int64, ttl time.Duration) (*models.Session, error) {
	now := time.Now()
	expires := now.Add(ttl)
	_, err := r.db.Exec(
		`INSERT INTO sessions (id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)`,
		id, userID, now, expires,
	)
	if err != nil {
		return nil, err
	}
	return &models.Session{ID: id, UserID: userID, CreatedAt: now, ExpiresAt: expires}, nil
}

func (r *SessionRepo) Get(id string) (*models.Session, error) {
	row := r.db.QueryRow(`SELECT id, user_id, created_at, expires_at FROM sessions WHERE id = ?`, id)
	var s models.Session
	err := row.Scan(&s.ID, &s.UserID, &s.CreatedAt, &s.ExpiresAt)
	if err == sql.ErrNoRows {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	return &s, nil
}

func (r *SessionRepo) Delete(id string) error {
	_, err := r.db.Exec(`DELETE FROM sessions WHERE id = ?`, id)
	return err
}

func (r *SessionRepo) DeleteExpired() error {
	_, err := r.db.Exec(`DELETE FROM sessions WHERE expires_at < ?`, time.Now())
	return err
}
