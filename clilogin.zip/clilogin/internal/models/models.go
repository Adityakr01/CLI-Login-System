package models

import "time"

// User represents an application user.
type User struct {
	ID             int64
	Username       string
	PasswordHash   string
	TOTPSecret     string // empty if 2FA not configured
	MFAEnabled     bool
	CreatedAt      time.Time
	LastLoginAt    *time.Time
	FailedAttempts int
	LockedUntil    *time.Time
}

// IsLocked reports whether the account is currently locked out.
func (u *User) IsLocked() bool {
	if u.LockedUntil == nil {
		return false
	}
	return time.Now().Before(*u.LockedUntil)
}

// Session represents an authenticated CLI session.
type Session struct {
	ID        string
	UserID    int64
	CreatedAt time.Time
	ExpiresAt time.Time
}

// IsExpired reports whether the session has timed out.
func (s *Session) IsExpired() bool {
	return time.Now().After(s.ExpiresAt)
}
