package cli

import (
	"os"
	"testing"

	"github.com/osto/clilogin/internal/db"
	"github.com/osto/clilogin/internal/repo"
)

func newTestService(t *testing.T) (*Service, func()) {
	t.Helper()
	f, err := os.CreateTemp("", "clilogin-test-*.db")
	if err != nil {
		t.Fatalf("temp file: %v", err)
	}
	f.Close()

	conn, err := db.Open(f.Name())
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	users := repo.NewUserRepo(conn)
	sessions := repo.NewSessionRepo(conn)
	svc := NewService(users, sessions)

	cleanup := func() {
		conn.Close()
		os.Remove(f.Name())
	}
	return svc, cleanup
}

func TestRegisterValidation(t *testing.T) {
	svc, cleanup := newTestService(t)
	defer cleanup()

	if err := svc.Register("ab", "longenoughpassword", "longenoughpassword"); err == nil {
		t.Error("expected error for short username")
	}
	if err := svc.Register("alice", "short", "short"); err == nil {
		t.Error("expected error for short password")
	}
	if err := svc.Register("alice", "longenoughpassword", "mismatch"); err == nil {
		t.Error("expected error for mismatched passwords")
	}
	if err := svc.Register("alice", "longenoughpassword", "longenoughpassword"); err != nil {
		t.Errorf("expected successful registration, got: %v", err)
	}
	if err := svc.Register("alice", "longenoughpassword", "longenoughpassword"); err == nil {
		t.Error("expected error for duplicate username")
	}
}

func TestLoginAndLockout(t *testing.T) {
	svc, cleanup := newTestService(t)
	defer cleanup()

	if err := svc.Register("bob", "correctpassword", "correctpassword"); err != nil {
		t.Fatalf("register: %v", err)
	}

	noTOTP := func() (string, error) { return "", nil }

	if err := svc.Login("bob", "wrongpassword", noTOTP); err == nil {
		t.Error("expected login failure for wrong password")
	}
	if err := svc.Login("bob", "correctpassword", noTOTP); err != nil {
		t.Fatalf("expected successful login, got: %v", err)
	}
	if !svc.LoggedIn() {
		t.Error("expected service to report logged in")
	}
	if err := svc.Logout(); err != nil {
		t.Fatalf("logout: %v", err)
	}
	if svc.LoggedIn() {
		t.Error("expected service to report logged out after Logout")
	}
}
