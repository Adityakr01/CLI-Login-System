package cli

import (
	"fmt"
	"strings"
	"time"

	"github.com/osto/clilogin/internal/auth"
	"github.com/osto/clilogin/internal/models"
	"github.com/osto/clilogin/internal/repo"
)

const issuerName = "CLILoginSystem"

// Service holds the application state and dependencies for the CLI.
type Service struct {
	Users    *repo.UserRepo
	Sessions *repo.SessionRepo

	currentUser    *models.User
	currentSession *models.Session
}

func NewService(users *repo.UserRepo, sessions *repo.SessionRepo) *Service {
	return &Service{Users: users, Sessions: sessions}
}

func (s *Service) LoggedIn() bool {
	if s.currentSession == nil {
		return false
	}
	if s.currentSession.IsExpired() {
		_ = s.Sessions.Delete(s.currentSession.ID)
		s.currentUser = nil
		s.currentSession = nil
		return false
	}
	return true
}

// ----- Registration -----

func (s *Service) Register(username, password, confirmPassword string) error {
	username = strings.TrimSpace(username)
	if len(username) < 3 {
		return fmt.Errorf("username must be at least 3 characters")
	}
	if len(password) < 8 {
		return fmt.Errorf("password must be at least 8 characters")
	}
	if password != confirmPassword {
		return fmt.Errorf("passwords do not match")
	}

	hash, err := auth.HashPassword(password)
	if err != nil {
		return fmt.Errorf("could not hash password: %w", err)
	}

	_, err = s.Users.Create(username, hash)
	if err != nil {
		if err == repo.ErrDuplicate {
			return fmt.Errorf("username %q is already taken", username)
		}
		return fmt.Errorf("could not create user: %w", err)
	}
	return nil
}

// ----- Login -----

// totpPrompt is called to ask the user for a 6-digit TOTP code if MFA is enabled.
type totpPrompt func() (string, error)

func (s *Service) Login(username, password string, promptTOTP totpPrompt) error {
	u, err := s.Users.GetByUsername(username)
	if err != nil {
		if err == repo.ErrNotFound {
			return auth.ErrInvalidCredentials
		}
		return err
	}

	if u.IsLocked() {
		return fmt.Errorf("%w until %s", auth.ErrAccountLocked, u.LockedUntil.Format(time.RFC1123))
	}

	if !auth.CheckPassword(u.PasswordHash, password) {
		_ = s.Users.RegisterFailedAttempt(u.ID, auth.MaxFailedAttempts, auth.LockoutDuration)
		return auth.ErrInvalidCredentials
	}

	if u.MFAEnabled {
		code, err := promptTOTP()
		if err != nil {
			return err
		}
		if !auth.ValidateTOTP(u.TOTPSecret, strings.TrimSpace(code)) {
			_ = s.Users.RegisterFailedAttempt(u.ID, auth.MaxFailedAttempts, auth.LockoutDuration)
			return auth.ErrInvalidTOTP
		}
	}

	token, err := auth.GenerateSessionToken()
	if err != nil {
		return err
	}
	session, err := s.Sessions.Create(token, u.ID, auth.SessionTTL)
	if err != nil {
		return err
	}

	if err := s.Users.RecordSuccessfulLogin(u.ID); err != nil {
		return err
	}
	// Refresh user record to pick up reset attempts / last_login_at.
	u, err = s.Users.GetByID(u.ID)
	if err != nil {
		return err
	}

	s.currentUser = u
	s.currentSession = session
	return nil
}

func (s *Service) Logout() error {
	if s.currentSession != nil {
		_ = s.Sessions.Delete(s.currentSession.ID)
	}
	s.currentUser = nil
	s.currentSession = nil
	return nil
}

// ----- Post-login actions -----

func (s *Service) WhoAmI() (string, error) {
	if !s.LoggedIn() {
		return "", fmt.Errorf("not logged in")
	}
	u := s.currentUser
	mfaStatus := "disabled"
	if u.MFAEnabled {
		mfaStatus = "enabled"
	}
	lastLogin := "never (first login)"
	if u.LastLoginAt != nil {
		lastLogin = u.LastLoginAt.Format(time.RFC1123)
	}

	var b strings.Builder
	fmt.Fprintf(&b, "Username:          %s\n", u.Username)
	fmt.Fprintf(&b, "Registered:        %s\n", u.CreatedAt.Format(time.RFC1123))
	fmt.Fprintf(&b, "MFA status:        %s\n", mfaStatus)
	fmt.Fprintf(&b, "Session expires:   %s\n", s.currentSession.ExpiresAt.Format(time.RFC1123))
	fmt.Fprintf(&b, "Last login:        %s\n", lastLogin)
	return b.String(), nil
}

// EnableTOTPStart generates a new secret/provisioning URI for the current
// user but does not persist it until ConfirmEnableTOTP succeeds.
func (s *Service) EnableTOTPStart() (secret, otpauthURL string, err error) {
	if !s.LoggedIn() {
		return "", "", fmt.Errorf("not logged in")
	}
	if s.currentUser.MFAEnabled {
		return "", "", fmt.Errorf("2FA is already enabled")
	}
	return auth.GenerateTOTPSecret(issuerName, s.currentUser.Username)
}

// ConfirmEnableTOTP verifies the user's first code and persists the secret.
func (s *Service) ConfirmEnableTOTP(secret, code string) error {
	if !s.LoggedIn() {
		return fmt.Errorf("not logged in")
	}
	if !auth.ValidateTOTP(secret, strings.TrimSpace(code)) {
		return auth.ErrInvalidTOTP
	}
	if err := s.Users.SetTOTPSecret(s.currentUser.ID, secret, true); err != nil {
		return err
	}
	s.currentUser.TOTPSecret = secret
	s.currentUser.MFAEnabled = true
	return nil
}

func (s *Service) DisableTOTP() error {
	if !s.LoggedIn() {
		return fmt.Errorf("not logged in")
	}
	if !s.currentUser.MFAEnabled {
		return fmt.Errorf("2FA is not enabled")
	}
	if err := s.Users.DisableMFA(s.currentUser.ID); err != nil {
		return err
	}
	s.currentUser.MFAEnabled = false
	s.currentUser.TOTPSecret = ""
	return nil
}

func (s *Service) CurrentUsername() string {
	if s.currentUser == nil {
		return ""
	}
	return s.currentUser.Username
}
