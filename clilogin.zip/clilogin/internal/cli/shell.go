package cli

import (
	"fmt"
	"strings"
	"syscall"

	"github.com/chzyer/readline"
	"golang.org/x/term"
)

const banner = `
  ██████╗██╗     ██╗    ██╗      ██████╗  ██████╗ ██╗███╗  ██╗
 ██╔════╝██║     ██║    ██║     ██╔═══██╗██╔════╝ ██║████╗ ██║
 ██║     ██║     ██║    ██║     ██║   ██║██║  ███╗██║██╔██╗██║
 ██║     ██║     ██║    ██║     ██║   ██║██║   ██║██║██║╚████║
 ╚██████╗███████╗██║    ███████╗╚██████╔╝╚██████╔╝██║██║ ╚███║
  ╚═════╝╚══════╝╚═╝    ╚══════╝ ╚═════╝  ╚═════╝ ╚═╝╚═╝  ╚══╝
  Containerized CLI Login System  |  TOTP 2FA
`

func loggedOutCompleter() *readline.PrefixCompleter {
	return readline.NewPrefixCompleter(
		readline.PcItem("register"),
		readline.PcItem("login"),
		readline.PcItem("help"),
		readline.PcItem("exit"),
	)
}

func loggedInCompleter() *readline.PrefixCompleter {
	return readline.NewPrefixCompleter(
		readline.PcItem("whoami"),
		readline.PcItem("enable-2fa"),
		readline.PcItem("disable-2fa"),
		readline.PcItem("logout"),
		readline.PcItem("help"),
	)
}

// Run starts the interactive REPL loop.
func (s *Service) Run(historyFile string) error {
	fmt.Print(banner)
	fmt.Println("Type 'help' to see available commands.")

	rl, err := readline.NewEx(&readline.Config{
		Prompt:          "clilogin> ",
		HistoryFile:     historyFile,
		AutoComplete:    loggedOutCompleter(),
		InterruptPrompt: "^C",
		EOFPrompt:       "exit",
	})
	if err != nil {
		return fmt.Errorf("init readline: %w", err)
	}
	defer rl.Close()

	for {
		if s.LoggedIn() {
			rl.Config.AutoComplete = loggedInCompleter()
			rl.SetPrompt(fmt.Sprintf("clilogin(%s)> ", s.CurrentUsername()))
		} else {
			rl.Config.AutoComplete = loggedOutCompleter()
			rl.SetPrompt("clilogin> ")
		}

		line, err := rl.Readline()
		if err != nil { // io.EOF or readline.ErrInterrupt
			fmt.Println("\nGoodbye!")
			return nil
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		cmd := strings.Fields(line)[0]

		switch {
		case !s.LoggedIn():
			s.dispatchLoggedOut(rl, cmd)
		default:
			if cmd == "exit" {
				fmt.Println("Please 'logout' before exiting, or use Ctrl+D / Ctrl+C.")
				continue
			}
			s.dispatchLoggedIn(rl, cmd)
		}

		if cmd == "exit" && !s.LoggedIn() {
			fmt.Println("Goodbye!")
			return nil
		}
	}
}

func (s *Service) dispatchLoggedOut(rl *readline.Instance, cmd string) {
	switch cmd {
	case "register":
		s.handleRegister(rl)
	case "login":
		s.handleLogin(rl)
	case "help":
		printHelp(false)
	case "exit":
		// handled by caller
	default:
		fmt.Printf("Unknown command: %s. Type 'help' for a list of commands.\n", cmd)
	}
}

func (s *Service) dispatchLoggedIn(rl *readline.Instance, cmd string) {
	switch cmd {
	case "whoami":
		out, err := s.WhoAmI()
		if err != nil {
			fmt.Println("Error:", err)
			return
		}
		fmt.Print(out)
	case "enable-2fa":
		s.handleEnable2FA(rl)
	case "disable-2fa":
		if err := s.DisableTOTP(); err != nil {
			fmt.Println("Error:", err)
			return
		}
		fmt.Println("2FA has been disabled.")
	case "logout":
		_ = s.Logout()
		fmt.Println("Logged out successfully.")
	case "help":
		printHelp(true)
	default:
		fmt.Printf("Unknown command: %s. Type 'help' for a list of commands.\n", cmd)
	}
}

func printHelp(loggedIn bool) {
	if !loggedIn {
		fmt.Println(`Available commands:
  register   Create a new user account
  login      Log in with username/password (+ TOTP if enabled)
  help       Show this help message
  exit       Quit the program`)
		return
	}
	fmt.Println(`Available commands:
  whoami       Show current user details
  enable-2fa   Enable TOTP-based 2FA (Google Authenticator compatible)
  disable-2fa  Disable 2FA
  logout       End the current session
  help         Show this help message`)
}

func (s *Service) handleRegister(rl *readline.Instance) {
	username, err := readLine(rl, "Username: ")
	if err != nil {
		return
	}
	password, err := readPassword("Password: ")
	if err != nil {
		fmt.Println("Error reading password:", err)
		return
	}
	confirm, err := readPassword("Confirm password: ")
	if err != nil {
		fmt.Println("Error reading password:", err)
		return
	}

	if err := s.Register(username, password, confirm); err != nil {
		fmt.Println("Registration failed:", err)
		return
	}
	fmt.Printf("User %q registered successfully. You can now log in.\n", username)
}

func (s *Service) handleLogin(rl *readline.Instance) {
	username, err := readLine(rl, "Username: ")
	if err != nil {
		return
	}
	password, err := readPassword("Password: ")
	if err != nil {
		fmt.Println("Error reading password:", err)
		return
	}

	promptTOTP := func() (string, error) {
		return readLine(rl, "2FA code: ")
	}

	if err := s.Login(username, password, promptTOTP); err != nil {
		fmt.Println("Login failed:", err)
		return
	}
	fmt.Printf("Welcome back, %s!\n\n", username)
	out, _ := s.WhoAmI()
	fmt.Print(out)
}

func (s *Service) handleEnable2FA(rl *readline.Instance) {
	secret, url, err := s.EnableTOTPStart()
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	fmt.Println("Scan this with Google Authenticator (or any TOTP app), or enter the secret manually:")
	fmt.Println("  Secret:", secret)
	fmt.Println("  otpauth URL:", url)
	fmt.Println("Tip: paste the otpauth URL into a QR generator to scan it visually.")

	code, err := readLine(rl, "Enter the 6-digit code from your app to confirm: ")
	if err != nil {
		return
	}
	if err := s.ConfirmEnableTOTP(secret, code); err != nil {
		fmt.Println("Could not enable 2FA:", err)
		return
	}
	fmt.Println("2FA has been enabled for your account.")
}

func readLine(rl *readline.Instance, prompt string) (string, error) {
	rl.SetPrompt(prompt)
	defer rl.SetPrompt("clilogin> ")
	line, err := rl.Readline()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(line), nil
}

// readPassword reads a line without echoing input to the terminal.
func readPassword(prompt string) (string, error) {
	fmt.Print(prompt)
	b, err := term.ReadPassword(int(syscall.Stdin))
	fmt.Println()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(b)), nil
}
