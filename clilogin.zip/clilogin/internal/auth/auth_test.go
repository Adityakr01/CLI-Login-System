package auth

import "testing"

func TestHashAndCheckPassword(t *testing.T) {
	hash, err := HashPassword("supersecret123")
	if err != nil {
		t.Fatalf("HashPassword returned error: %v", err)
	}
	if !CheckPassword(hash, "supersecret123") {
		t.Error("expected correct password to validate")
	}
	if CheckPassword(hash, "wrongpassword") {
		t.Error("expected wrong password to fail validation")
	}
}

func TestGenerateTOTPSecretAndValidate(t *testing.T) {
	secret, url, err := GenerateTOTPSecret("TestIssuer", "alice")
	if err != nil {
		t.Fatalf("GenerateTOTPSecret returned error: %v", err)
	}
	if secret == "" || url == "" {
		t.Fatal("expected non-empty secret and otpauth URL")
	}
	// An arbitrary code should not validate against a fresh secret.
	if ValidateTOTP(secret, "000000") {
		t.Log("note: extremely unlikely but not impossible that 000000 was valid at this instant")
	}
}

func TestGenerateSessionTokenUnique(t *testing.T) {
	t1, err := GenerateSessionToken()
	if err != nil {
		t.Fatalf("GenerateSessionToken error: %v", err)
	}
	t2, err := GenerateSessionToken()
	if err != nil {
		t.Fatalf("GenerateSessionToken error: %v", err)
	}
	if t1 == t2 {
		t.Error("expected two generated session tokens to differ")
	}
	if len(t1) != 64 { // 32 bytes hex-encoded
		t.Errorf("expected token length 64, got %d", len(t1))
	}
}
