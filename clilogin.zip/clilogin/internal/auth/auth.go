package auth

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"time"

	"github.com/pquerna/otp/totp"
	"golang.org/x/crypto/bcrypt"
)

const (
	// MaxFailedAttempts is the number of consecutive failed logins allowed
	// before an account is locked out.
	MaxFailedAttempts = 5
	// LockoutDuration is how long an account stays locked after exceeding
	// MaxFailedAttempts.
	LockoutDuration = 5 * time.Minute
	// SessionTTL is the default session timeout.
	SessionTTL = 15 * time.Minute
)

var ErrInvalidCredentials = errors.New("invalid username or password")
var ErrAccountLocked = errors.New("account is locked due to too many failed attempts")
var ErrInvalidTOTP = errors.New("invalid 2FA code")

// HashPassword hashes a plaintext password using bcrypt.
func HashPassword(password string) (string, error) {
	b, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(b), nil
}

// CheckPassword compares a plaintext password against a bcrypt hash.
func CheckPassword(hash, password string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)) == nil
}

// GenerateTOTPSecret creates a new TOTP secret and provisioning URI for the
// given account/issuer, suitable for rendering as a QR code or for manual
// entry into an authenticator app.
func GenerateTOTPSecret(issuer, accountName string) (secret string, otpauthURL string, err error) {
	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      issuer,
		AccountName: accountName,
	})
	if err != nil {
		return "", "", err
	}
	return key.Secret(), key.URL(), nil
}

// ValidateTOTP checks a 6-digit code against the stored secret.
func ValidateTOTP(secret, code string) bool {
	return totp.Validate(code, secret)
}

// GenerateSessionToken returns a cryptographically random, hex-encoded
// session identifier.
func GenerateSessionToken() (string, error) {
	buf := make([]byte, 32)
	if _, err := rand.Read(buf); err != nil {
		return "", fmt.Errorf("generate session token: %w", err)
	}
	return hex.EncodeToString(buf), nil
}

