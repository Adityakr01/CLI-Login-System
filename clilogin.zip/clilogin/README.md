# CLI Login System with 2FA

A command line login system built with Go. It supports user registration, login, and optional two factor authentication using Google Authenticator.

---

## What it does

- Register a new user
- Login with username and password
- Enable or disable 2FA (Google Authenticator)
- Auto locks account after 5 wrong attempts
- Session expires after 15 minutes
- All data saved in SQLite database

---

## Tech Used

- Go
- SQLite
- Docker
- bcrypt (for password security)
- TOTP (for 2FA)

---

## How to Run

### Without Docker

Make sure you have Go installed, then run:

```bash
go mod tidy
go run . -db ./clilogin.db -history ./.history
```

### With Docker

```bash
docker compose run --rm clilogin
```

---

## Commands

**Before login:**

| Command | What it does |
|---|---|
| register | Create a new account |
| login | Login to your account |
| help | Show all commands |
| exit | Close the app |

**After login:**

| Command | What it does |
|---|---|
| whoami | Show your account info |
| enable-2fa | Turn on Google Authenticator |
| disable-2fa | Turn off Google Authenticator |
| logout | Logout from your account |
| help | Show all commands |

---

## How to enable 2FA

1. Login to your account
2. Type `enable-2fa`
3. Copy the secret key or URL shown
4. Open Google Authenticator on your phone
5. Tap + and enter the secret key
6. Enter the 6 digit code shown in the app
7. Done

---

## Tests

```bash
go test ./...
```

---

## Project Files

```
main.go        - starting point
db.go          - database setup
auth.go        - password and token logic
store.go       - database queries
service.go     - main app logic
shell.go       - command line interface
```
